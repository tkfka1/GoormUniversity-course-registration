<script setup lang="ts">
import TestApi from '../components/TestApi.vue'
</script>

<template>
  <main>
    <TestApi />
  </main>
</template>
